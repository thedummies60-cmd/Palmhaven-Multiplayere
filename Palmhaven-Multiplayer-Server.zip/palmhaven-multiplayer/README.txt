PALMHAVEN MULTIPLAYER

Deze versie gebruikt geen PeerJS-room meer. Multiplayer loopt via een echte Node.js-server met Socket.IO en een SQLite-database.

BENODIGD
- Node.js 20+ aanbevolen.
- Internet/LAN afhankelijk van waar je de server host.

STARTEN OP WINDOWS
1. Installeer Node.js.
2. Dubbelklik op start.bat.
3. De browser opent http://localhost:3000.
4. Speler 1: Multiplayer -> Room maken.
5. Speler 2: open dezelfde server-URL en vul de room-code in.

OP ANDERE COMPUTERS IN JE NETWERK
- Zoek het lokale IP van de pc die de server draait, bijvoorbeeld 192.168.1.50.
- Andere pc's openen http://192.168.1.50:3000.
- Windows Firewall moet inkomende TCP op poort 3000 toestaan.

ONLINE OP INTERNET
- Host deze map op een server/VPS die Node.js kan draaien.
- Gebruik een HTTPS-domein zodra je hem publiek maakt.

DATABASE
De server maakt automatisch data/palmhaven.sqlite aan.
- rooms: room-codes, limieten en activiteit
- players: spelers, namen en laatste multiplayer-state
- realtime bewegingen gaan via Socket.IO; de database wordt ongeveer 1x per seconde per speler bijgewerkt zodat hij niet onnodig wordt volgeschreven.

CONTROLE
- /health geeft serverstatus terug.
