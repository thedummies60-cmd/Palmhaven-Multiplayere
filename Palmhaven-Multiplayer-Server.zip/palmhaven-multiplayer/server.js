'use strict';

const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const Database = require('better-sqlite3');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  maxHttpBufferSize: 1e6,
  pingInterval: 10000,
  pingTimeout: 20000,
  connectionStateRecovery: {
    maxDisconnectionDuration: 120000,
    skipMiddlewares: true,
  },
});

const dataDir = path.join(__dirname, 'data');
const fs = require('fs');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'palmhaven.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');

db.exec(`
CREATE TABLE IF NOT EXISTS rooms (
  code TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL,
  last_active_at INTEGER NOT NULL,
  max_players INTEGER NOT NULL DEFAULT 4,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS players (
  player_id TEXT PRIMARY KEY,
  room_code TEXT NOT NULL,
  display_name TEXT NOT NULL,
  last_seen_at INTEGER NOT NULL,
  state_json TEXT NOT NULL DEFAULT '{}',
  FOREIGN KEY(room_code) REFERENCES rooms(code) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_players_room ON players(room_code);
`);

const q = {
  roomGet: db.prepare('SELECT * FROM rooms WHERE code = ? AND active = 1'),
  roomCreate: db.prepare('INSERT INTO rooms (code, created_at, last_active_at, max_players, active) VALUES (?, ?, ?, 4, 1)'),
  roomTouch: db.prepare('UPDATE rooms SET last_active_at = ?, active = 1 WHERE code = ?'),
  roomDeactivate: db.prepare('UPDATE rooms SET active = 0, last_active_at = ? WHERE code = ?'),
  playerUpsert: db.prepare(`INSERT INTO players (player_id, room_code, display_name, last_seen_at, state_json)
    VALUES (@player_id, @room_code, @display_name, @last_seen_at, @state_json)
    ON CONFLICT(player_id) DO UPDATE SET room_code=excluded.room_code, display_name=excluded.display_name,
      last_seen_at=excluded.last_seen_at, state_json=excluded.state_json`),
  playerState: db.prepare('UPDATE players SET last_seen_at = ?, state_json = ? WHERE player_id = ?'),
  playerDelete: db.prepare('DELETE FROM players WHERE player_id = ?'),
  oldRooms: db.prepare('SELECT code FROM rooms WHERE active = 1 AND last_active_at < ?'),
  oldDeactivate: db.prepare('UPDATE rooms SET active = 0 WHERE code = ?'),
};

function cleanCode(value) {
  return String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
}
function makeCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let tries = 0; tries < 50; tries++) {
    let code = '';
    for (let i = 0; i < 6; i++) code += alphabet[Math.floor(Math.random() * alphabet.length)];
    if (!q.roomGet.get(code)) return code;
  }
  throw new Error('Could not allocate room code');
}
function cleanName(value) {
  const name = String(value || 'Speler').trim().replace(/[<>]/g, '').slice(0, 20);
  return name || 'Speler';
}
function validId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{8,80}$/.test(value);
}
function finite(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(-100000, Math.min(100000, n)) : fallback;
}
function safeState(s) {
  if (!s || typeof s !== 'object') return null;
  return {
    x: finite(s.x), y: finite(s.y), z: finite(s.z), yaw: finite(s.yaw),
    aiming: !!s.aiming, weapon: typeof s.weapon === 'string' ? s.weapon.slice(0, 20) : null,
    dead: !!s.dead,
    vehicleKey: typeof s.vehicleKey === 'string' ? s.vehicleKey.slice(0, 20) : null,
    vx: finite(s.vx), vy: finite(s.vy), vz: finite(s.vz), vh: finite(s.vh), vsx: finite(s.vsx), vsz: finite(s.vsz), vf: finite(s.vf), ty: finite(s.ty),
  };
}
function roomSockets(code) {
  return io.sockets.adapter.rooms.get(`room:${code}`) || new Set();
}
function playerSnapshot(code, exceptSocketId) {
  const out = [];
  for (const sid of roomSockets(code)) {
    if (sid === exceptSocketId) continue;
    const s = io.sockets.sockets.get(sid);
    if (!s?.data?.playerId) continue;
    out.push({
      playerId: s.data.playerId,
      displayName: s.data.displayName,
      state: s.data.state || null,
    });
  }
  return out;
}
function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  socket.leave(`room:${code}`);
  socket.data.roomCode = null;
  const now = Date.now();
  q.roomTouch.run(now, code);
  if (roomSockets(code).size === 0) q.roomTouch.run(now, code);
}

app.use(express.static(path.join(__dirname, 'public'), {
  etag: true,
  maxAge: '1h',
}));
app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'Palmhaven Multiplayer', database: 'SQLite', time: Date.now() });
});

io.on('connection', (socket) => {
  socket.on('room:create', (payload, ack) => {
    const done = typeof ack === 'function' ? ack : () => {};
    try {
      const playerId = validId(payload?.playerId) ? payload.playerId : `p_${socket.id.replace(/[^A-Za-z0-9]/g, '').slice(0, 18)}`;
      const displayName = cleanName(payload?.displayName);
      if (socket.data.roomCode) leaveRoom(socket);
      const code = makeCode();
      const now = Date.now();
      q.roomCreate.run(code, now, now);
      socket.data.playerId = playerId;
      socket.data.displayName = displayName;
      socket.data.roomCode = code;
      socket.data.state = null;
      socket.join(`room:${code}`);
      q.playerUpsert.run({ player_id: playerId, room_code: code, display_name: displayName, last_seen_at: now, state_json: '{}' });
      done({ ok: true, code, playerId, players: [] });
    } catch (err) {
      console.error('[room:create]', err);
      done({ ok: false, error: 'Kon geen room maken.' });
    }
  });

  socket.on('room:join', (payload, ack) => {
    const done = typeof ack === 'function' ? ack : () => {};
    try {
      const code = cleanCode(payload?.code);
      const room = q.roomGet.get(code);
      if (!room || code.length !== 6) return done({ ok: false, error: 'Room niet gevonden.' });
      const members = roomSockets(code).size;
      if (members >= Math.min(4, room.max_players)) return done({ ok: false, error: 'Deze room is vol (max. 4 spelers).' });
      const playerId = validId(payload?.playerId) ? payload.playerId : `p_${socket.id.replace(/[^A-Za-z0-9]/g, '').slice(0, 18)}`;
      const displayName = cleanName(payload?.displayName);
      if (socket.data.roomCode) leaveRoom(socket);
      const now = Date.now();
      socket.data.playerId = playerId;
      socket.data.displayName = displayName;
      socket.data.roomCode = code;
      socket.data.state = null;
      socket.join(`room:${code}`);
      q.playerUpsert.run({ player_id: playerId, room_code: code, display_name: displayName, last_seen_at: now, state_json: '{}' });
      q.roomTouch.run(now, code);
      const players = playerSnapshot(code, socket.id);
      done({ ok: true, code, playerId, players });
      socket.to(`room:${code}`).emit('player:joined', { playerId, displayName });
    } catch (err) {
      console.error('[room:join]', err);
      done({ ok: false, error: 'Kon niet met de room verbinden.' });
    }
  });

  socket.on('room:rejoin', (payload, ack) => {
    const done = typeof ack === 'function' ? ack : () => {};
    const code = cleanCode(payload?.code);
    if (!code || !validId(payload?.playerId)) return done({ ok: false, error: 'Ongeldige room.' });
    const room = q.roomGet.get(code);
    if (!room) return done({ ok: false, error: 'Room bestaat niet meer.' });
    if (roomSockets(code).size >= 4) return done({ ok: false, error: 'Room is vol.' });
    try {
      if (socket.data.roomCode) leaveRoom(socket);
      const now = Date.now();
      socket.data.playerId = payload.playerId;
      socket.data.displayName = cleanName(payload.displayName);
      socket.data.roomCode = code;
      socket.data.state = null;
      socket.join(`room:${code}`);
      q.playerUpsert.run({ player_id: socket.data.playerId, room_code: code, display_name: socket.data.displayName, last_seen_at: now, state_json: '{}' });
      q.roomTouch.run(now, code);
      done({ ok: true, code, playerId: socket.data.playerId, players: playerSnapshot(code, socket.id) });
      socket.to(`room:${code}`).emit('player:joined', { playerId: socket.data.playerId, displayName: socket.data.displayName });
    } catch (err) {
      done({ ok: false, error: 'Opnieuw verbinden is mislukt.' });
    }
  });

  socket.on('player:state', (payload) => {
    const code = socket.data.roomCode;
    if (!code || !payload) return;
    const state = safeState(payload.state);
    if (!state) return;
    socket.data.state = state;
    socket.data._lastStateDb = socket.data._lastStateDb || 0;
    const now = Date.now();
    if (now - socket.data._lastStateDb >= 1000) {
      socket.data._lastStateDb = now;
      try { q.playerState.run(now, JSON.stringify(state), socket.data.playerId); q.roomTouch.run(now, code); } catch (err) { console.warn('[state db]', err.message); }
    }
    socket.to(`room:${code}`).volatile.emit('player:state', {
      playerId: socket.data.playerId,
      displayName: socket.data.displayName,
      state,
    });
  });

  socket.on('player:action', (payload) => {
    const code = socket.data.roomCode;
    if (!code || !payload || typeof payload.type !== 'string') return;
    const type = payload.type.slice(0, 24);
    // Action events are intentionally descriptive only; game-side validation remains local.
    socket.to(`room:${code}`).volatile.emit('player:action', {
      playerId: socket.data.playerId,
      type,
      at: Date.now(),
    });
  });

  socket.on('room:leave', () => leaveRoom(socket));

  socket.on('disconnect', () => {
    const code = socket.data.roomCode;
    const playerId = socket.data.playerId;
    if (code && playerId) {
      try {
        if (socket.data.state) q.playerState.run(Date.now(), JSON.stringify(socket.data.state), playerId);
        q.roomTouch.run(Date.now(), code);
      } catch (_) {}
      socket.to(`room:${code}`).emit('player:left', { playerId });
    }
  });
});

setInterval(() => {
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  for (const row of q.oldRooms.all(cutoff)) q.oldDeactivate.run(row.code);
}, 15 * 60 * 1000).unref();

server.listen(PORT, HOST, () => {
  console.log(`Palmhaven Multiplayer running on http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
  console.log('SQLite database: data/palmhaven.sqlite');
});
