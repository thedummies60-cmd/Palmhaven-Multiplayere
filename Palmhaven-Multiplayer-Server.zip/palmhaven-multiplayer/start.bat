@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 (
    echo.
    echo Installation failed. Make sure Node.js is installed.
    pause
    exit /b 1
  )
)
echo.
echo Palmhaven Multiplayer is starting...
echo Open http://localhost:3000
start "" http://localhost:3000
node server.js
pause
